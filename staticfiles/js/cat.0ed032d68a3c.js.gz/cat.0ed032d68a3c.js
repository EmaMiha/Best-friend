document.getElementById("addBtn").addEventListener("click", function () {
    
        setTimeout(() => {
            window.location.href = "home.html";  
        }, 3000);
    
});